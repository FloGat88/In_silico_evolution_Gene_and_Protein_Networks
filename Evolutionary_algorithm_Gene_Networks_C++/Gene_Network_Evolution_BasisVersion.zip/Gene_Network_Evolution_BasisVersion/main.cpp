
#include "EvoAlg.h"

int main()
{
 //   EvoAlg_2PeakScaling();
    
    EvoAlg Evolution;
    Evolution();
    return 0;
}



    
    
    
